<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.10.2" name="tiles" tilewidth="8" tileheight="8" tilecount="448" columns="32">
 <image source="new_tiles.png" width="256" height="116"/>
</tileset>
